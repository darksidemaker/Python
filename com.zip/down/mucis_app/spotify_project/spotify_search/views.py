from django.shortcuts import render
from .utils import get_token, search_artist, get_song

def index(request):
    return render(request, 'spotify_search/index.html')

def search(request):
    if request.method == 'POST':
        artist_name = request.POST.get('artist_name')
        token = get_token()
        result = search_artist(token, artist_name)
        if result:
            artis = result["artists"]["items"]
            track= result["tracks"]["items"]
            album= result["albums"]["items"]
            
            return render(request, 'spotify_search/index.html', {'artists': artis, 'tracks': track, 'albums':album})
        else:
            message = "No artist found with that name."
            return render(request, 'spotify_search/index.html', {'message': message})
    return render(request, 'spotify_search/index.html')
