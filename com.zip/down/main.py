
import os
import base64
from requests import post, get
import json



client_id = os.getenv("CLIENT_ID")
client_secret = os.getenv("CLIENT_SECRET")

def get_token():
    auth_string = client_id + ":" + client_secret
    auth_bytes = auth_string.encode("utf-8")
    auth_base64 = str(base64.b64encode(auth_bytes), "utf-8")
    
    url = " https://accounts.spotify.com/api/token"
    headers={
        "Authorization": "Basic " + auth_base64,
        "Content-Type": "application/x-www-form-urlencoded"
    }
    data = {"grant_type": "client_credentials"}
    result = post(url, headers=headers, data=data)
    json_result =  json.loads(result.content)
    token = json_result["access_token"]
    return token

def get_auth_header(token):
    return{"Authorization": "Bearer " + token}

def search_artist(token, artist_name):
    url = "https://api.spotify.com/v1/search"
    headers = get_auth_header(token)
    query = f"q={artist_name}&type=track%2Cartist%2Calbum&limit=10"
    
    query_url = url +"?"+ query
    # print(query_url)
    result = get(query_url, headers=headers)
    json_result =  json.loads(result.content)
    if len(json_result)==0:
        print("No artist with this name......")
        return None
    # print(json_result)
    return json_result

def get_song(token, artist_id):
    url = f"https://api.spotify.com/v1/artists/{artist_id}/top-tracks?country=IN"
    headers = get_auth_header(token)
    result = get(url, headers=headers)
    json_result =  json.loads(result.content)["tracks"]
    return json_result

# def get_track(token, trcak_id):
#     url = f"https://api.spotify.com/v1/tracks/{trcak_id}"
#     headers = get_auth_header(token)
#     result = get(url, headers=headers)
#     json_result =  json.loads(result.content)
#     return json_result
    
def get_track(token, track_id):
    url = f"https://api.spotify.com/v1/tracks/{track_id}"
    headers = get_auth_header(token)
    
    try:
        result = get(url, headers=headers)
        result.raise_for_status()
        json_result = result.json()
        return json_result
    except Exception as e:
        print("Error occurred while getting track:", e)
        return None


token = get_token()
art_sh=input("Enter Artist name: ")
result =search_artist(token,art_sh)
artists = result["artists"]["items"]
songs = result["tracks"]["items"]
albums = result["albums"]["items"]
# print(artists)
# songs = get_song(token, artist_id)

track_id = songs[0]["id"]
track_info = get_track(token, track_id)
if track_info:
    print("Track Name:", track_info["name"])
    print("Album:", track_info["album"]["name"])
    print("Release Date:", track_info["album"]["release_date"])
    print("Duration (ms):", track_info["duration_ms"])

def get_track_playback_link(track_id):
    return f"https://open.spotify.com/track/{track_id}"

# track_id = "5iWLSf8n91COHj5nP0Pxvk"  # Example track ID
# playback_link = get_track_playback_link(track_id)
# print("Playback Link:", playback_link)

# text=get_track(token, track_id)
# print("\track_id:")
# print(text)
# for idx, trackid in enumerate(track_id):
#     print(f"{idx + 1}. {trackid}")

print("\nartists:")
for idx, artist in enumerate(artists):
    print(f"{idx + 1}. {artist['name']}")

# print("\nsongs:")
# for idx, song in enumerate(songs):
#     print(f"{idx + 1}. {song['name']}")
    
print("\nalbums:")
for idx, album in enumerate(albums):
    print(f"{idx + 1}. {album['name']}")
    

print(track_info['album']['images'])